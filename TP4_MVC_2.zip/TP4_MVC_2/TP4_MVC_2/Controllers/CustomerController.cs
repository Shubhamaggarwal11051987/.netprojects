﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TP4_MVC_2.Models;

namespace TP4_MVC_2.Controllers
{
    public class CustomerController : Controller
    {
        private CustomerOperation customerOperation;
        public CustomerController()
        {
            customerOperation = new CustomerOperation();
        }
        public IActionResult Index()
        {
            // string message = "I am dynamic content...";
            // ViewBag.msg = message;
            //ViewData["data"] = message;

            //  var customers = new List<string>() { "Ajay","Manish","Suraj","Rohit","pawan"};
            //  ViewBag.customer = customers;
            // ViewData["customer"] = customers;
            var customers = customerOperation.GetCustomers();
            return View(customers);
        }

        public IActionResult Create()
        {
            return View();
        }
    }
}
